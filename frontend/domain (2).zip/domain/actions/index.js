import axios from 'axios'

export const PARSE_DATA = Symbol('PARSE_DATA')

export function parseData(data) {
  return {
    type: PARSE_DATA,
    payload: data
  }
}

export function fetchData() {
  return (dispatch) => {
    axios.get('/domain.json').then((response) => {
      dispatch(parseData(response.data))
    })
  }
}
