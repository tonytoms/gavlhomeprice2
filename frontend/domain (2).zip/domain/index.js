import React from 'react'
import thunk from 'redux-thunk'
import { render } from 'react-dom'
import { createStore, applyMiddleware } from 'redux'
import Reboot from 'material-ui/Reboot'
import { BrowserRouter } from 'react-router-dom'
import { Provider as ReduxProvider } from 'react-redux'
import { MuiThemeProvider, createMuiTheme } from 'material-ui/styles'

import './index.css'
import reducers from './reducers'
import AppContainer from './containers/AppContainer'

const store = createStore(reducers, applyMiddleware(thunk))
const muiTheme = createMuiTheme()

render(
  <ReduxProvider store={store}>
    <BrowserRouter>
      <MuiThemeProvider theme={muiTheme}>
        <Reboot />
        <AppContainer />
      </MuiThemeProvider>
    </BrowserRouter>
  </ReduxProvider>,
  document.getElementById('app')
)
