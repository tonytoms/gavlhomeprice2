import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'

import App from '../components/App'
import { fetchData } from '../actions'

let mapStateToProps = (state) => {
  return {
    items: state ? state : []
  }
}

let mapDispatchToProps = (dispatch) => {
  return bindActionCreators({ fetchData }, dispatch)
}
export default  connect(mapStateToProps, mapDispatchToProps)(App)
