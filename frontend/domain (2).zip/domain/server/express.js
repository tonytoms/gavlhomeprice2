const express = require('express')

var app = express()

app.use(express.static(__dirname + '/../bundle'))

app.use(function(req, res, next) {
  var err = new Error('Route Not Found')
  err.status = 404
  next(err)
})

app.use(function(err, req, res, next) {
  res.status(err.status || 500).json({"error": {
    message: err.message
  }})
})

app.listen(3000, function () {
  console.log('Express app listening on port 3000')
})
