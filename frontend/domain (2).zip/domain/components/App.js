import React, { Component } from 'react'
import AppBar from 'material-ui/AppBar'
import Toolbar from 'material-ui/Toolbar'
import ReactTable from 'react-table'
import Paper from 'material-ui/Paper'
import Typography from 'material-ui/Typography'
import { List, AutoSizer } from 'react-virtualized'
import TextField from 'material-ui/TextField'
import alasql from 'alasql'
import Button from 'material-ui/Button'
import Grid from 'material-ui/Grid'

import 'react-table/react-table.css'

export default class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      filters: {},
      filteredItems: []
    }
    this.widths = {
       //"Id": 50,
       //"UnitNumber": 100,
       //"StreetNumber": 110,

       //"StreetName": 200,
       //"SuburbName": 150,
       //"SuburbCode": 100,

       //"SoldDate": 100,
       //"DayOfWeek": 100,
       //"DayType":0,
       //"HolidayStatus":150,
       //"SoldStatus":0,
       //"PropertyType":0,
       //"Bed":0,
       ///"Bath":0,
       //"Garage":0,
       //"LongTermResidentPercent":200,
       //"RentedResidentPercent":200,
       //"SingleResident":150,
       "Garden":0,
       "Pool":0,
       "Heating":0,
       "Cooling":0,
       //"AvgDaysOnMarketSuburb":200,
       "PropertySoldInSuburb":200,
       //"LandSize":0,
       "BuildYear":0,
       "NumOfTimesSold":150,
       "NumOfTimesRented":150,
       "LastSoldPrice":0,
       "LastRentedPrice":0,
       "LastSoldYear":0,
       "LastRentedYear":0,
       "MinTemp":0,
       "MaxTemp":0,
       "AvgRainfall":0,
       //"DistanceCBD":0,
       //"DistanceRailwayStation":200,
       //"DistanceBusStation":150,
       //"DistanceShoppingMall":200,
       //"DistanceSchool":0,
       //"PriceLowEnd":0,
       //"PriceHighEnd":0,
       //"Frontage":0,
       //"Slop":0,
       "ExternalPricePrediction":200,
       "SimilarPropertyPrice1":200,
       "SimilarPropertyPrice2":200,
       "SalePrice":0
    }
  }

  componentWillMount() {
    this.props.fetchData()
  }

  render() {
    let columns = [{ Header: '', accessor: (a) => (
      <Paper key={a.Id}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{display: 'inline-block', width: 200 }}>
            <img src={`http://p-hold.com/building/${200+parseInt(a.Id%10)}/${200+parseInt(a.Id%10)}`} style={{maxWidth: 200, maxHeight: 200}} />
            <div style={{ fontWeight: 500, textAlign: 'center', padding: 30 }}>Listing: {a.Id}</div>
            <div style={{ textAlign: 'center', padding: 10 }}>Status: <span style={{ textTransform: 'uppercase' }}>{a.SoldStatus}</span></div>
          </div>
          <Grid container style={{ flex: 1, padding: 30 }}>
            <Grid item xs={12}>
              <h2>{a.StreetNumber} {a.StreetName}, {a.SuburbName}, {a.SuburbCode}</h2>
            </Grid>
            <Grid item xs={12}>
              <h3>${a.PriceLowEnd} - ${a.PriceHighEnd}</h3>
            </Grid>
            <Grid item xs={12} style={{ paddingTop: 20 }}>
              <h4>Bed: {a.Bed} &nbsp;&nbsp;&nbsp; Bath: {a.Bath} &nbsp;&nbsp;&nbsp; Garage: {a.Garage} &nbsp;&nbsp;&nbsp; Size: {a.LandSize} m<sup>2</sup> &nbsp;&nbsp;&nbsp; Type: {a.PropertyType}</h4>
            </Grid>
            <Grid item xs={12} style={{ paddingTop: 40 }}>
              <h3>Other Info</h3>
            </Grid>
            {Object.keys(this.widths).map((key) => (
              <Grid item xs={3} key={key}>
                {key}: {a[key]}
              </Grid>
            ))}
          </Grid>
        </div>
      </Paper>
    ), id: 1 }]

    return (
      <div style={{display: 'flex', flexDirection: 'column', height: '100vh'}}>
        <div>
          <AppBar position="static" color="default">
            <Toolbar>
              <Typography type="title" color="inherit">
                GAVL Home Price Estimator
              </Typography>
            </Toolbar>
          </AppBar>
        </div>
        <div style={{ flex: 1, background: 'grey' }}>
          <Paper style={{ margin: 30 }}>
            <ReactTable
              data={this.props.items}
              minRows={2}
              sortable={true}
              filterable={true}
              defaultFilterMethod={(filter, row) => {
                let regex = new RegExp(`.*${filter.value}.*`)
                return row['_original'].StreetName.match(regex) || row['_original'].SuburbName.match(regex) || String(row['_original'].SuburbCode).match(regex)
              }}
              columns={columns}
              onPageChange={this.clearSelection}
              onPageSizeChange={this.clearSelection}
              onFilteredChange={this.clearSelection}
            />
          </Paper>
        </div>
      </div>
    )
  }
}
