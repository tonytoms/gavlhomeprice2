import { PARSE_DATA } from '../actions'

export default function rootReducer(state=null, action) {
  switch(action.type) {
    case PARSE_DATA:
      return action.payload
  }
  return state
}
